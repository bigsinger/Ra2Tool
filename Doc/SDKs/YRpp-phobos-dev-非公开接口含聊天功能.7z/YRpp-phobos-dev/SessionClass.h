#pragma once

#include <cstddef>

#include <GeneralDefinitions.h>
#include <MPGameModeClass.h>
#include <GameModeOptionsClass.h>
#include <IPX.h>
#include <MessageListClass.h>

#include <Helpers/CompileTime.h>
#include <CCFileClass.h>

struct SessionOptionsClass
{
    int MPGameMode;
    int ScenIndex;
    int GameSpeed;
    int Credits;
    int UnitCount;
    bool ShortGame;
    bool SuperWeaponsAllowed;
    bool BuildOffAlly;
    bool MCVRepacks;
    bool CratesAppear;
    Vector3D<int> SlotData[8];
};

struct PlayerData {
    std::byte Data[10];
    PROTECTED_PROPERTY(BYTE, align_A[2])
};

#pragma pack(push, 1)
struct NodeNameType {
    wchar_t Name[20];
    PlayerData Data;
    char Serial[23];
    int Country;
    int InitialCountry;
    int Color;
    int InitialColor;
    int StartPoint;
    int InitialStartPoint;
    int Team;
    int InitialTeam;
    DWORD unknown_int_6B;
    int HouseIndex;
    int Time;
    DWORD unknown_int_77;
    int Clan;
    DWORD unknown_int_7F;
    BYTE unknown_byte_83;
    BYTE unknown_byte_84;
};
#pragma pack(pop)

enum NetCommandType
{
    NET_QUERY_GAME = 0x0,
    NET_ANSWER_GAME = 0x1,
    NET_QUERY_PLAYER = 0x2,
    NET_ANSWER_PLAYER = 0x3,
    NET_CHAT_ANNOUNCE = 0x4,
    NET_CHAT_REQUEST = 0x5,
    NET_QUERY_JOIN = 0x6,
    NET_CONFIRM_JOIN = 0x7,
    NET_REJECT_JOIN = 0x8,
    NET_GAME_OPTIONS = 0x9,
    NET_SIGN_OFF = 0xA,
    NET_GO = 0xB,
    NET_MESSAGE = 0xC,
    NET_PING = 0xD,
    NET_LOADGAME = 0xE,
    NET_ProgressLoading = 0xF,
    NET_Taunts = 0x1D,
    NET_BeaconPlace = 0x20,
    NET_BeaconDelete = 0x21,
    NET_BeaconSendText = 0x22,
    NET_REQ_SCENARIO = 0x3E8,
    NET_FILE_INFO = 0x3E9,
    NET_FILE_CHUNK = 0x3EA,
    NET_READY_TO_GO = 0x3EB,
    NET_NO_SCENARIO = 0x3EC,
};

// enum ServerPacketType: unsigned char
// {
//     NET_RamboPlay_SyncTick = 0x0,
//     NET_RamboPlay_StartGame = 0x1,
//     NET_RamboPlay_EndGame = 0x2,
//     NET_RamboPlay_InvalidGame = 0x3,
//     NET_RamboPlay_FrameDiff = 0x4,

//     NET_RamboPlay_Sync_APM = 0x10,
//     NET_RamboPlay_Sync_SegRenderTime = 0x11,
//     NET_RamboPlay_Sync_RenderTime = 0x12,
// };


#pragma pack(push, 1)
// struct ServerPacket
// {
//     ServerPacketType Command;
//     union
//     {
//         struct
//         {
//             int AP1M;
//             int APM;
//         } APM;

//         struct
//         {
//             int One;
//             int Ten;
//             int Hundred;
//         } SegRenderTime;

//         struct
//         {
//             int RenderFpsUnder300;
//         } RenderTime;
//     };
// };
struct GlobalPacketType
{
    NetCommandType Command;
    // __int16 Name[20];
    char Name[43];
    union
    {
        struct
        {
            // char Data[411]; // 0x1C3
            char Data[408];
        } SpaceGap;
        struct
        {
            // char Data[3];
            int Progress;
        } ProgressLoading;
        struct
        {
            // char Data[3];
            bool Unknown;
            char Buf[224];
            int PlayerColor;
            int NameCRC;
        } Message;
        struct
        {
            // char Data[3];
            bool Unknown;
            int TauntsIndex;
        } Taunts;
        struct
        {
            // char Data[3];
            int CoordX;
            int CoordY;
            int CoordZ;
            char Index;
            char PlayerIndex;
        } BeaconPlaceDelete;
        struct
        {
            // char Data[3];
            char a2;
            char a3;
            char Source[256];
        } BeaconSendText;

    } GlobalPacketData;
};
#pragma pack(pop)

#pragma pack(push, 4)
class SessionClass
{
public:
    static constexpr reference<SessionClass, 0xA8B238u> const Instance{};

    static bool IsCampaign()
    {
        return Instance->GameMode == GameMode::Campaign;
    }

    static bool IsSingleplayer()
    {
        return Instance->GameMode == GameMode::Campaign
            || Instance->GameMode == GameMode::Skirmish;
    }

    static int GetPlayerColor(int house_id)
    {
        for (int i = 0; i < SessionClass::Instance->Chat.Count; ++i)
        {
            auto item = SessionClass::Instance->Chat.GetItem(i);
            if (house_id == item->HouseIndex)
            {
                return item->Color;
            }
        }
        return -1;
    }
    static int GetPlayerCountry(int house_id)
    {
        for (int i = 0; i < SessionClass::Instance->Chat.Count; ++i)
        {
            auto item = SessionClass::Instance->Chat.GetItem(i);
            if (house_id == item->HouseIndex)
            {
                return item->Country;
            }
        }
        return -1;
    }

    GameMode GameMode;
    MPGameModeClass* MPGameMode;
    DWORD unknown_08;
    DWORD unknown_0C;
    DWORD unknown_10;
    DWORD ProtocolVersion;
    GameModeOptionsClass Config;
    DWORD UniqueID;
    char Handle[20];
    int PlayerColor;
    DWORD unknown_160;
    DWORD unknown_164;
    DWORD unknown_168;
    DWORD unknown_16C;
    DWORD unknown_170;
    int idxSide;
    int idxSide2;
    int Color;
    int Color2;
    int Side;
    int Side2;
    SessionOptionsClass Skirmish;
    SessionOptionsClass LAN;
    SessionOptionsClass WOL;
    BOOL MultiplayerObserver;
    DWORD Unknown_304;
    bool WOLLimitResolution;
    int LastNickSlot;
    int MPlayerMax;
    int MPlayerCount;
    int MaxAhead;
    int FrameSendRate;
    int DesiredFrameRate;
    int ProcessTimer;
    int ProcessTicks;
    int ProcessFrames;
    int MaxMaxAhead;
    int PrecalcMaxAhead;
    int PrecalcDesiredFrameRate;
    struct
    {
        char Name[64];
        int MaxRoundTrip;
        int Resends;
        int Lost;
        int PercentLost;
        int MaxAvgRoundTrip;
        int FrameSyncStalls;
        int CommandCoundStalls;
        IPXAddressClass Address;
    } MPStats[8];
    bool EnableMultiplayerDebug;
    bool DrawMPDebugStats;
    char field_67E;
    char field_67F;
    int LoadGame;
    int SaveGame;
    char field_688;
    bool SawCompletion;
    bool OutOfSync;
    char field_68B;
    int GameVersion;
    DynamicVectorClass<class MultiMission*> MultiMission;
    char ScenarioFilename[0x202]; // 0x6A8
    char ScenarioDigest[34];
    int ScenarioFileLength;
    char ScenarioIsOfficial;
    int ScenarioMaxPlayers;
    char PlayersToSendScenario[8];
    int ScenarioSentCount;
    IPXAddressClass HostAddress[3];
    PROTECTED_PROPERTY(char, array_908[32]);
    PROTECTED_PROPERTY(char, array_928[256]);
    MessageListClass Messages;
    IPXAddressClass MessageAddress;
    char SomeMask[8];
    bool LANTaunts;
    bool WOLTaunts;
    wchar_t LastMessage[113];
    int Bitfield;
    char LANScrollText;
    char WOLScrollText;
    char field_1FC2;
    char field_1FC3;
    struct MPlayerScoreType
    {
        char Name[40];
        int Scheme;
        int NonGameOvers;
        int Lost[4];
        int Kills[4];
        int Built[4];
        int Score[4];
    } Score[8];
    int GamesPlayed;
    int NumScores;
    int Winner;
    int CurGame;
    CCFileClass RecordFile;
    //int AttractBitfield;
    unsigned Record : 1;
    unsigned Play : 1;
    unsigned Attract : 1;

    int IsBridge;
    IPXAddressClass BridgeNet;
    char NetStealth;
    char NetProtect;
    char NetOpen;
    wchar_t GameName[20];
    GlobalPacketType GPacket;
    char field_25C7;
    int GPacketLen;
    IPXAddressClass GAddress;
    short GProductID;
    char MetaPacket[558];
    int MetaSize;
    DynamicVectorClass<NodeNameType*> Games;
    DynamicVectorClass<NodeNameType*> Players;
    DynamicVectorClass<NodeNameType*> Chat;
    //PROTECTED_PROPERTY(DWORD, unknown_2854[0x220]);
    //int TrapPrintCRC;
    //bool CurrentlyInGame; // at least used for deciding dialog backgrounds
    PROTECTED_PROPERTY(DWORD, unknown_2854);
    PROTECTED_PROPERTY(DWORD, name_pointer);
    PROTECTED_PROPERTY(char, unknown_285C[32]);
    int maybe_mutex_287C;
    PROTECTED_PROPERTY(char, unknown_2880[228]);
    int LatencyFudge;
    PROTECTED_PROPERTY(DWORD, unknown_2968);
    PROTECTED_PROPERTY(DWORD, a_connection_pointer);
    PROTECTED_PROPERTY(char, unknown_2970[20]);
    PROTECTED_PROPERTY(wchar_t, PacketRouterPort);
    PROTECTED_PROPERTY(char, unknown_2986[1690]);
    PROTECTED_PROPERTY(wchar_t, name[21]);
    PROTECTED_PROPERTY(char, unknown_304A[42]);
    PROTECTED_PROPERTY(DWORD, ret_sub_664440);
    PROTECTED_PROPERTY(char, unknown_3078[2]);
    PROTECTED_PROPERTY(wchar_t, PacketRouterPortArray[8]);
    PROTECTED_PROPERTY(char, unknown_308A[22]);
    CDTimerClass unknown_30A0;
    PROTECTED_PROPERTY(char, unknown_30AC[40]);
    DWORD TrapPrintCRC;
    DWORD CurrentlyInGame;
};
#pragma pack(pop)

static_assert(sizeof(SessionClass) == 0x30DC);
