#pragma once

#include <Helpers/CompileTime.h>

struct IPXAddressClass
{
	unsigned char NetworkNumber[4];
	__declspec(align(4)) unsigned char NodeAddress[6];
};
static_assert(sizeof(IPXAddressClass) == 0xC);

struct CommBufferClass
{
	virtual ~CommBufferClass() RX;

	unsigned int MaxSend;
	unsigned int MaxReceive;
	unsigned int MaxPacketSize;
	unsigned int MaxExtraSize;
	unsigned int DelaySum;
	unsigned int NumDelay;
	unsigned int MeanDelay;
	unsigned int MaxDelay;
	void* SendQueue;
	unsigned int SendCount;
	unsigned int SendTotal;
	int* SendIndex;
	void* ReceiveQueue;
	unsigned int ReceiveCount;
	unsigned int ReceiveTotal;
	int* ReceiveIndex;
	int DebugOffset;
	int DebugSize;
	int DebugNames;
	int DebugNameStart;
	int DebugNameCount;
};
static_assert(sizeof(CommBufferClass) == 0x58);

class ConnectionClass
{
public:
	virtual ~ConnectionClass() RX;
	virtual void Init(void) RX;
	virtual int Send_Packet(void* buf, int buflen, int ack_req, char) R0;
	virtual int Receive_Packet(void* buf, int buflen) R0;
	virtual int Get_Packet(void* buf, int* buflen) R0;
	virtual int Service() R0;
	virtual int Service_Send_Queue() RX;
	virtual int Service_Receive_Queue() RX;
	virtual int Send(char* buf, int buflen, void* extrabuf, int extralen) R0;

	CommBufferClass* Queue;
	int Resends;
	int NumLost;
	int PercentLost;
	int MissedOverall;
	int MissedMagic;
	int MaxPacketLen;
	char* PacketBuf;
	unsigned short MagicNum;
	unsigned long RetryDelta;
	unsigned long MaxRetries;
	unsigned long Timeout;
	unsigned long NumRecNoAck;
	unsigned long NumRecAck;
	unsigned long NumSendNoAck;
	unsigned long NumSendAck;
	unsigned long LastSeqID;
	unsigned long LastReadID;
};
static_assert(sizeof(ConnectionClass) == 0x4C);

typedef unsigned char NetNodeType[6];
class IPXConnClass : public ConnectionClass
{
public:
	IPXAddressClass Address;
	NetNodeType ImmediateAddress;
	unsigned int Immed_Set;
	unsigned int ID;
	wchar_t Name[40];
};
static_assert(sizeof(IPXConnClass) == 0xB8);

struct IPXGlobalConnClass : public IPXConnClass
{
	short Unknown1;
	char Net[4];
	char Node[6];
	int IsBridge;
	char field_C8;
	char field_C9;
	char field_CA;
	char field_CB;
	int IPAddresses;
	int* LastPacketID;
	int Uknknown4;
	int LastRXIndex;
};
static_assert(sizeof(IPXGlobalConnClass) == 0xDC);

class ConnManClass
{
public:
	enum IPXConnTag { CONNECTION_NONE = -1 };
	virtual ~ConnManClass() RX;
	virtual int Service(void) = 0;
	virtual int Send_Private_Message(void* buf, int buflen, int ack_req = 1, int conn_id = CONNECTION_NONE) = 0;
	virtual int Get_Private_Message(void* buf, int* buflen, int* conn_id) = 0;
	virtual int Num_Connections(void) = 0;
	virtual int Connection_ID(int index) = 0;
	virtual int Connection_Index(int id) = 0;
	virtual int Global_Num_Send(void) = 0;
	virtual int Global_Num_Receive(void) = 0;
	virtual int Private_Num_Send(int id = CONNECTION_NONE) = 0;
	virtual int Private_Num_Receive(int id = CONNECTION_NONE) = 0;
	virtual void Reset_Response_Time(void) = 0;
	virtual unsigned long Response_Time(void) = 0;
	virtual void Set_Timing(unsigned long retrydelta, unsigned long maxretries, unsigned long timeout) = 0;
	virtual void Configure_Debug(int index, int type_offset, int type_size, char** names, int namestart, int namecount) = 0;
};

class IPXManagerClass : public ConnManClass
{
public:
public:
	static constexpr reference<IPXManagerClass, 0xA8E9C0> const Instance{};

	unsigned char IPXStatus;
	unsigned char Listening;
	unsigned int Glb_MaxPacketLen;
	int Glb_NumPackets;
	unsigned int Pvt_MaxPacketLen;
	unsigned int Pvt_NumPackets;
	unsigned int Ext_MaxPacketLen;
	unsigned int Ext_MaxPackets;
	unsigned short ProductID;
	unsigned short Socket;
	unsigned int ConnectionNum;
	IPXConnClass* Connection[7];
	unsigned int NumConnections;
	IPXGlobalConnClass* GlobalChannel;
	IPXGlobalConnClass* IPXGlobalConn2;
	ConnectionClass* MulticastConnection;
	unsigned int CurConnection;
	unsigned int RetryDelta;
	unsigned int MaxRetries;
	unsigned int Timeout;
	int Global1RetryDelta;
	int Global1Timing;
	int Global1RetryTimeout;
	char field_70;
	char field_71;
	char field_72;
	char field_73;
	int field_74;
	char field_78;
	char field_79;
	char field_7A;
	char field_7B;
	int field_7C;
	int field_80;
	int field_84;
	int field_88;
	int field_8C;
	int field_90;
	int field_94;
	int field_98;
	int field_9C;
	unsigned int SendOverflows;
	unsigned int ReceiveOverflows;
	unsigned int BadConnection;
};
static_assert(sizeof(IPXManagerClass) == 0xAC);

